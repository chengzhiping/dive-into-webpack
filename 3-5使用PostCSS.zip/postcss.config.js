module.exports = {
  plugins: [
    // 需要使用的插件列表
    require('postcss-cssnext'),
  ]
}
